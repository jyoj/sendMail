package com.example.sim.customerSim.service;

import java.util.List;

import com.example.sim.customerSim.entity.CustomerEntity;

public interface CustomerService {

	public List<CustomerEntity> getAllCustomers();

}
