package com.example.sim.customerSim.service;

import java.util.List;

import com.example.sim.customerSim.entity.SimEntity;

public interface SimService  {

	List<SimEntity> getAllSims();

}
