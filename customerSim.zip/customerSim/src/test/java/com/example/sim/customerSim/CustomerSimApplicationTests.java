package com.example.sim.customerSim;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerSimApplicationTests {

	@Test
	void contextLoads() {
	}

}
